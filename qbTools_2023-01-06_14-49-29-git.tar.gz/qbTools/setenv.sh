#/bin/bash
#set -x
ARCH=`dpkg --print-architecture`
GID=`id -g`

echo "UID=${UID}" > .env
echo "GID=`id -g`" >> .env

sudo chown -R $UID:$GID ./*

if [ "$ARCH" = "arm64" ];
then
  cp -p docker-compose.yaml-64bit docker-compose.yaml
else
  cp -p docker-compose.yaml-32bit docker-compose.yaml
fi
