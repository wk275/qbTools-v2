#!/bin/bash
#set -x

ARG_COUNT=0
while getopts "a:b:c:e:j:p:s:t:xihd" flag
do
    case "${flag}" in
        a) EXPORT_ADDRESS=${OPTARG};;
        b) BUCKET=${OPTARG};;
        c) CONTAINER_ID_SOURCE=${OPTARG};;
	e) END=${OPTARG};;
        j) CONTAINER_ID_TARGET=${OPTARG};;
	p) PASSWORD=${OPTARG};;
	s) START=${OPTARG};;
	t) TOKEN=${OPTARG};;
	x) EXPORT="x";;
	i) IMPORT="i";;
	h) HELP="h";;
	d) DELETE="d";;
    esac
    ARG_COUNT=$((ARG_COUNT+1))
done
if [ "$HELP" == "h" ] || [ ${ARG_COUNT} -eq 0 ];then

	echo
	echo "-h help"
	echo
	echo
	echo "----------------------------------------------------------------------------------------------------"
	echo Influx buckets are exported to a subdir export in the current derectory
	echo This script requires software sshpass and a ssh connection to the source system. If not setup: 
	echo "- install sshpass => sudo apt-get install sshpass"
	echo "- setup ssh 	=> ssh-keygen -t rsa -b 4096"
	echo "- 	 	=> ssh-copy-id <target user@ipaddress>"
	echo "----------------------------------------------------------------------------------------------------"
	echo
	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
	echo export, import and cleanup parameters can be used in a single statement or can be executed one by one. E.g.
	echo ./Influx_data-migration.sh -x -a odroid@192.168.22.172 -p sshpassword -c influxdbV2-prd -b qbus -s 2023-01-01T00:00:00Z -e 2023-12-31T23:59:59Z 
	echo ./Influx_data-migration.sh -i -c influxdbV2-prd -j influxdbV2-qb -b qbus -t \"influxdbToken\"
	echo ./Influx_data-migration.sh -d -c influxdbV2-prd -j influxdbV2-qb -b qbus
	echo --- OR ---
	echo ./Influx_data-migration.sh -x -a odroid@192.168.22.172 -p sshpassword -c influxdbV2-prd -b qbus -s 2023-01-01T00:00:00Z -e 2023-12-31T23:59:59Z -i -j influxdbV2-qb -t \"influxdbToken\" -d
	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
	echo
	echo
	echo "-------------------------------"
	echo "required export parameters are:"
	echo "-------------------------------"
	echo "-x indicates that this is an export"
	echo "-a <user@ipaddress> ssh user and ip address of source influxdb"
	echo "-p <password> ssh password of source"
	echo "-c <container-id-source>"
	echo "-b <bucket name>"
	echo "-s <start time> in format 2023-01-01T00:00:00Z"
	echo "-e <end time> in format 2023-01-01T00:00:00Z"
	echo
	echo "-------------------------------"
	echo "required import parameters are:"
	echo "-------------------------------"
	echo "-i indicates that this is an import"
	echo "-c <container-id-source>"
	echo "-j <container-id-target>"
	echo "-b <bucket name>"
	echo "-t <token> influx security token of target"
	echo
	echo "--------------------------------"
	echo "required cleanup parameters are:"
	echo "--------------------------------"
	echo "-d cleanup export files & directories"
	echo "-c <container-id source>"
	echo "-j <container-id target>"
	echo "-b <bucket name>"
fi

FILENAME=./export/${CONTAINER_ID_SOURCE}_export_${BUCKET}

######################## export ################
exp(){
	echo "----------------------------------------------------"
	echo export influxdb $CONTAINER_ID_SOURCE $BUCKET
	echo "----------------------------------------------------"
	mkdir export > /dev/null 2>&1
	BUCKET_ID=`sshpass -p $PASSWORD ssh $EXPORT_ADDRESS docker exec $CONTAINER_ID_SOURCE influx bucket list|grep -v _|grep $BUCKET|awk '{ print $1 }'`
	sshpass -p $PASSWORD ssh $EXPORT_ADDRESS docker exec $CONTAINER_ID_SOURCE influxd inspect export-lp --engine-path /var/lib/influxdb2/engine --bucket-id $BUCKET_ID --output-path  "-"  --start $START --end $END > $FILENAME
	echo "----------------------------------------------------"
}
if [ "$EXPORT" == "x" ];then
	exp;
fi

######################## import ################
imp(){
	echo "--------------------------------------------------------------------------------------"
	echo importing influxdb $CONTAINER_ID_SOURCE $BUCKET to $CONTAINER_ID_TARGET $BUCKET
	echo "--------------------------------------------------------------------------------------"
	echo splitting $FILENAME
	split -C 9m --numeric-suffixes $FILENAME ${FILENAME}_split
	echo $FILENAME splitted in `ls ${FILENAME}_split*|wc -l` files
	for f in ${FILENAME}_split*; do
		echo import $f
		docker cp ${f} ${CONTAINER_ID_TARGET}':/var/lib/influxdb2/' > /dev/null 2>&1
		docker exec $CONTAINER_ID_TARGET influx write -b $BUCKET -o nodered --format=lp -f /var/lib/influxdb2/$(basename -- "$f") -t $TOKEN ; 
                docker exec ${CONTAINER_ID_TARGET} rm /var/lib/influxdb2/$(basename -- "$f") > /dev/null 2>&1
	done
	echo "--------------------------------------------------------------------------------------"
}

if [ "$IMPORT" == "i" ];then
	imp;
fi



######################## cleanup ################
cleanup(){
	echo "----------------------------------------------------"
	echo cleanup files and directory 
	for f in ${FILENAME}_split*; do
                docker exec ${CONTAINER_ID_TARGET} rm /var/lib/influxdb2/$(basename -- "$f") > /dev/null 2>&1
        done

	rm ${FILENAME}_split* > /dev/null 2>&1
	rm $FILENAME >  /dev/null 2>&1
	rmdir export >  /dev/null 2>&1
	echo "----------------------------------------------------"
}
if [ "$DELETE" == "d" ];then
	cleanup;
fi
