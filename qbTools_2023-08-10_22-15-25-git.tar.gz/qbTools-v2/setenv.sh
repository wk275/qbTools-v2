#/bin/bash
#set -x

ARCH=`dpkg --print-architecture`
GID=`id -g`

echo "UID=${UID}" > .env
echo "GID=`id -g`" >> .env

sudo chown -R $UID:$GID ./*

if [[ "$ARCH" == *"64"* ]];
then
  cp -p docker-compose.yaml-64bit docker-compose.yaml
  cp -p docker-compose_qbusmqtt-openhab.yaml-64bit docker-compose_qbusmqtt-openhab.yaml
  echo "COMPOSE_FILE=docker-compose_qbusmqtt-openhab.yaml:docker-compose.yaml" >> .env
  read -p "$(echo -e -Enter your qbus serial number: )" SERIAL
  
  sudo cp -p ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json_orig ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json
  sudo sed -i 's/"sn": "000000"/"sn": "'${SERIAL}'"/' ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json
  
else
  cp -p docker-compose.yaml-32bit docker-compose.yaml
fi
