#/bin/bash
#set -x

ARCH=`dpkg --print-architecture`
GID=`id -g`

sudo chown -R $UID:$GID ./*

echo "UID=${UID}" > .env
echo "GID=`id -g`" >> .env


if [[ "$ARCH" == *"64"* ]];
then
  cp -p docker-compose.yaml-64bit docker-compose.yaml

  read -p "$(echo -e -Enter your qbus serial number: )" SERIAL

  ###### process Qbus serial number
  if [[ "$SERIAL" !=  "" ]];
  then 
    cp -p Dockerfile-64bit_${ARCH} ./Dockerfile
    cp -p docker-compose_qbusmqtt.yaml-64bit docker-compose_qbusmqtt.yaml
    echo "COMPOSE_FILE=docker-compose_qbusmqtt.yaml:docker-compose.yaml" >> .env

    sudo cp -p ./nodered/data/flows.json_orig_qbTools ./nodered/data/flows.json
    sudo sed -i 's/"ctdSn": "999999",/"ctdSn": "'${SERIAL}'",/' ./nodered/data/flows.json

  else
    rm ./docker-compose_qbusmqtt.yaml > /dev/null 2>&1
    echo no serial number entered. Qbusmqtt will not be installed 
  fi 

  ###### change port numbers and qbTools suffix -qb
  echo ""
  read -p "$(echo -e -Enter port number prefix. Default is original port numbers: )" PORTPREFIX
  echo ""
  read -p "$(echo -e -Enter qbTools suffix. Default is -qb : )" QBSUFFIX

  if [[ "$QBSUFFIX" ==  "" ]];
  then 
    QBSUFFIX="-qb"
  fi
  sed -i 's/\"1/\"'$PORTPREFIX'/' ./docker-compose_qbusmqtt.yaml
  sed -i 's/\-qb/'$QBSUFFIX'/' ./docker-compose_qbusmqtt.yaml
  sed -i 's/image: qbusmqtt:latest/image: qbusmqtt'$QBSUFFIX':latest/' ./docker-compose_qbusmqtt.yaml

  sed -i 's/\"1/\"'$PORTPREFIX'/' ./docker-compose.yaml
  sed -i 's/\-qb/'$QBSUFFIX'/' ./docker-compose.yaml

  sed -i 's/\:1/\:'$PORTPREFIX'/' ./Dockerfile

else
  echo qbtools does not suport a 32-bit OS architecture 
fi
#cleanup
rm -rf .git > /dev/null 2>&1 
rm -rf qbTools_*git.tar.gz*
rm README.md > /dev/null 2>&1
