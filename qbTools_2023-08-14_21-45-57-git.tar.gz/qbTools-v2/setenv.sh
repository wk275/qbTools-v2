#/bin/bash
#set -x

ARCH=`dpkg --print-architecture`
GID=`id -g`

echo "UID=${UID}" > .env
echo "GID=`id -g`" >> .env

sudo chown -R $UID:$GID ./*

if [[ "$ARCH" == *"64"* ]];
then
  cp -p docker-compose.yaml-64bit docker-compose.yaml
  sudo cp -p ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json_orig ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json
  read -p "$(echo -e -Enter your qbus serial number: )" SERIAL
  if [[ "$SERIAL" !=  "" ]];
  then 
    cp -p docker-compose_qbusmqtt-openhab.yaml-64bit docker-compose_qbusmqtt-openhab.yaml
    sudo sed -i 's/"sn": "000000"/"sn": "'${SERIAL}'"/' ./openhab/userdata/jsondb/org.openhab.core.thing.Thing.json
    echo "COMPOSE_FILE=docker-compose_qbusmqtt-openhab.yaml:docker-compose.yaml" >> .env
  else
    rm ./docker-compose_qbusmqtt-openhab.yaml > /dev/null 2>&1
    echo no serial number entered. Openhab and qbusmqtt will be be installed 
  fi 
else
  echo qbtools does not suport a 32-bit OS architecture 
fi
#cleanup
rm -rf .git > /dev/null 2>&1 
rm -rf qbTools_*git.tar.gz*
