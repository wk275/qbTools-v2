Your rules go here.
All rule files have to have the ".rules" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/rules-dsl.html
